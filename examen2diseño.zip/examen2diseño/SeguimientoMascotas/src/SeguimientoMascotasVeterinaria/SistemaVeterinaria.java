package SeguimientoMascotasVeterinaria;

import java.time.LocalDate;
import java.util.*;

public class SistemaVeterinaria {

    private Map<String, Dueño> dueños;                       
    private Map<String, List<Mascota>> mascotas;             
    private Map<Mascota, List<ControlVeterinario>> controles;

    public SistemaVeterinaria() {
        this.dueños = new HashMap<>();
        this.mascotas = new HashMap<>();
        this.controles = new HashMap<>();
    }

    public Map<String, Dueño> getDueños() { return dueños; }
    public void setDueños(Map<String, Dueño> dueños) { this.dueños = dueños; }

    public Map<String, List<Mascota>> getMascotas() { return mascotas; }
    public void setMascotas(Map<String, List<Mascota>> mascotas) { this.mascotas = mascotas; }

    public Map<Mascota, List<ControlVeterinario>> getControles() { return controles; }
    public void setControles(Map<Mascota, List<ControlVeterinario>> controles) { this.controles = controles; }

    public Dueño registrarDueño(String documento, String nombre, String telefono) {
        Dueño d = new Dueño(documento, nombre, telefono);
        dueños.put(documento, d);
        mascotas.putIfAbsent(documento, new ArrayList<>());
        return d;
    }

    public Mascota registrarMascota(String documentoDueño, String nombre, String especie, int edad) {
        Dueño d = dueños.get(documentoDueño);
        if (d == null) throw new IllegalArgumentException("Dueño no existe: " + documentoDueño);

        List<Mascota> lista = mascotas.computeIfAbsent(documentoDueño, k -> new ArrayList<>());

        for (Mascota m : lista) {
            if (m.getNombre().equalsIgnoreCase(nombre)) {
                throw new IllegalArgumentException("Mascota duplicada para este dueño: " + nombre);
            }
        }

        Mascota m = new Mascota(nombre, especie, edad, d);
        lista.add(m);
        controles.putIfAbsent(m, new ArrayList<>());
        return m;
    }

    public ControlVeterinario registrarControl(String documentoDueño,
                                               String nombreMascota,
                                               TipoControl tipo,
                                               LocalDate fecha,
                                               String observaciones) {
        Mascota m = buscarMascota(documentoDueño, nombreMascota);
        if (m == null) throw new IllegalArgumentException("Mascota no existe: " + nombreMascota);

        ControlVeterinario c = new ControlVeterinario(fecha, tipo, observaciones, m);
        controles.computeIfAbsent(m, k -> new ArrayList<>()).add(c);
        return c;
    }

    public List<ControlVeterinario> historialPorMascota(String documentoDueño, String nombreMascota) {
        Mascota m = buscarMascota(documentoDueño, nombreMascota);
        if (m == null) throw new IllegalArgumentException("Mascota no existe: " + nombreMascota);
        return Collections.unmodifiableList(controles.getOrDefault(m, new ArrayList<>()));
    }

    public String resumenPorMascota(String documentoDueño, String nombreMascota) {
        Mascota m = buscarMascota(documentoDueño, nombreMascota);
        if (m == null) throw new IllegalArgumentException("Mascota no existe: " + nombreMascota);
        List<ControlVeterinario> hs = controles.getOrDefault(m, new ArrayList<>());

        StringBuilder sb = new StringBuilder();
        sb.append("Resumen Mascota\n");
        sb.append("Nombre: ").append(m.getNombre()).append("\n");
        sb.append("Especie: ").append(m.getEspecie()).append("\n");
        sb.append("Edad: ").append(m.getEdad()).append("\n");
        sb.append("Dueño: ").append(m.getDueño().getNombreCompleto()).append(" (")
          .append(m.getDueño().getDocumento()).append(")\n");
        sb.append("Controles registrados: ").append(hs.size()).append("\n");
        return sb.toString();
    }

    private Mascota buscarMascota(String documentoDueño, String nombreMascota) {
        List<Mascota> lista = mascotas.getOrDefault(documentoDueño, Collections.emptyList());
        for (Mascota m : lista) {
            if (m.getNombre().equalsIgnoreCase(nombreMascota)) return m;
        }
        return null;
    }

    @Override
    public String toString() {
        return "SistemaVeterinaria{" +
                "dueños=" + dueños.size() +
                ", mascotas=" + mascotas.values().stream().mapToInt(List::size).sum() +
                ", controles=" + controles.values().stream().mapToInt(List::size).sum() +
                '}';
    }
}