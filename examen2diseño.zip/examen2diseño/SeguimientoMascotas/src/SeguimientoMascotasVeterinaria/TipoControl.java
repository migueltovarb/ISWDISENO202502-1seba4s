package SeguimientoMascotasVeterinaria;

public enum TipoControl {
	VACUNA,
	CHEQUEO,
	DESPARASITACION,
	OTRO

}