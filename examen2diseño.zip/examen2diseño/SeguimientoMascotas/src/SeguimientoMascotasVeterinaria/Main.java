package SeguimientoMascotasVeterinaria;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    private static final Scanner SC = new Scanner(System.in);
    private static final SistemaVeterinaria SYS = new SistemaVeterinaria();

    public static void main(String[] args) {
        SC.useLocale(Locale.US);

        while (true) {
            System.out.println();
            System.out.println("===== MENU VETERINARIA =====");
            System.out.println("1) Registrar dueño");
            System.out.println("2) Registrar mascota");
            System.out.println("3) Registrar control veterinario");
            System.out.println("4) Ver historial de una mascota");
            System.out.println("5) Ver resumen de una mascota");
            System.out.println("0) Salir");
            System.out.print("Opción: ");
            String op = SC.nextLine().trim();

            try {
                switch (op) {
                    case "1" -> registrarDueño();
                    case "2" -> registrarMascota();
                    case "3" -> registrarControl();
                    case "4" -> verHistorial();
                    case "5" -> verResumen();
                    case "0" -> { System.out.println("Adiós."); return; }
                    default -> System.out.println("Opción inválida");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void registrarDueño() {
        System.out.println("--- Registrar dueño ---");
        System.out.print("Documento: ");
        String doc = SC.nextLine().trim();
        System.out.print("Nombre completo: ");
        String nombre = SC.nextLine().trim();
        System.out.print("Teléfono: ");
        String tel = SC.nextLine().trim();

        var d = SYS.registrarDueño(doc, nombre, tel);
        System.out.println("Registrado: " + d);
    }

    private static void registrarMascota() {
        System.out.println("--- Registrar mascota ---");
        System.out.print("Documento del dueño: ");
        String doc = SC.nextLine().trim();
        System.out.print("Nombre de la mascota: ");
        String nombre = SC.nextLine().trim();
        System.out.print("Especie (Perro/Gato/etc): ");
        String especie = SC.nextLine().trim();
        int edad = leerEnteroPositivo("Edad (años): ");

        var m = SYS.registrarMascota(doc, nombre, especie, edad);
        System.out.println("Registrada: " + m);
    }

    private static void registrarControl() {
        System.out.println("--- Registrar control veterinario ---");
        System.out.print("Documento del dueño: ");
        String doc = SC.nextLine().trim();
        System.out.print("Nombre de la mascota: ");
        String nombre = SC.nextLine().trim();

        System.out.println("Tipos de control:");
        TipoControl[] tipos = TipoControl.values();
        for (int i = 0; i < tipos.length; i++) {
            System.out.println((i + 1) + ") " + tipos[i]);
        }
        int idx = leerEnteroRango("Seleccione tipo (1-" + tipos.length + "): ", 1, tipos.length);
        TipoControl tipo = tipos[idx - 1];

        LocalDate fecha = leerFecha("Fecha (YYYY-MM-DD): ");

        System.out.print("Observaciones: ");
        String obs = SC.nextLine().trim();

        var c = SYS.registrarControl(doc, nombre, tipo, fecha, obs);
        System.out.println("Control registrado: " + c);
    }

    private static void verHistorial() {
        System.out.println("--- Historial de mascota ---");
        System.out.print("Documento del dueño: ");
        String doc = SC.nextLine().trim();
        System.out.print("Nombre de la mascota: ");
        String nombre = SC.nextLine().trim();

        List<ControlVeterinario> hist = SYS.historialPorMascota(doc, nombre);
        if (hist.isEmpty()) {
            System.out.println("Sin controles registrados.");
            return;
        }
        System.out.println("Controles (" + hist.size() + "):");
        for (ControlVeterinario c : hist) {
            System.out.println("- " + c);
        }
    }

    private static void verResumen() {
        System.out.println("--- Resumen de mascota ---");
        System.out.print("Documento del dueño: ");
        String doc = SC.nextLine().trim();
        System.out.print("Nombre de la mascota: ");
        String nombre = SC.nextLine().trim();

        String resumen = SYS.resumenPorMascota(doc, nombre);
        System.out.println(resumen);
    }

    // ===== utilidades de entrada =====

    private static int leerEnteroPositivo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String in = SC.nextLine().trim();
            try {
                int v = Integer.parseInt(in);
                if (v <= 0) throw new NumberFormatException();
                return v;
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un entero positivo.");
            }
        }
    }

    private static int leerEnteroRango(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String in = SC.nextLine().trim();
            try {
                int v = Integer.parseInt(in);
                if (v < min || v > max) throw new NumberFormatException();
                return v;
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un entero en el rango [" + min + ", " + max + "].");
            }
        }
    }

    private static LocalDate leerFecha(String prompt) {
        while (true) {
            System.out.print(prompt);
            String in = SC.nextLine().trim();
            try {
                return LocalDate.parse(in);
            } catch (Exception e) {
                System.out.println("Formato inválido. Use YYYY-MM-DD (ej: 2025-10-08).");
            }
        }
    }
}