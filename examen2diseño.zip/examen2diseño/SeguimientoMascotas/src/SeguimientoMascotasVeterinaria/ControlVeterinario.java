package SeguimientoMascotasVeterinaria;

import java.time.LocalDate;
import java.math.BigDecimal;

public class ControlVeterinario {
    private LocalDate fecha;
    private TipoControl tipo;
    private String observaciones;
    private Mascota mascota;

    public ControlVeterinario() {}

    public ControlVeterinario(LocalDate fecha, TipoControl tipo, String observaciones, Mascota mascota) {
        this.fecha = fecha;
        this.tipo = tipo;
        this.observaciones = observaciones;
        this.mascota = mascota;
    }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public TipoControl getTipo() { return tipo; }
    public void setTipo(TipoControl tipo) { this.tipo = tipo; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public Mascota getMascota() { return mascota; }
    public void setMascota(Mascota mascota) { this.mascota = mascota; }

    public BigDecimal subtotal() {
        return BigDecimal.ZERO;
    }

    @Override
    public String toString() {
        return "ControlVeterinario{" +
                "fecha=" + fecha +
                ", tipo=" + tipo +
                ", observaciones='" + observaciones + '\'' +
                ", mascota=" + (mascota != null ? mascota.getNombre() : "null") +
                '}';
    }
}